/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hcsr04;

/**
 *
 * @author default
 */
public class Main {

    public static void main(String[] args) {
        int triggerPinNumber = 5;
        int echoPinNumber = 6;
        HCSR04 hcsr04 = new HCSR04(triggerPinNumber, echoPinNumber);
        while (true) {
            System.out.println("Distance: " + hcsr04.getDistance());
        }
    }
}
