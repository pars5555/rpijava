/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hcsr04;

import com.pi4j.io.gpio.GpioPinDigitalOutput;
import com.pi4j.io.gpio.GpioPinDigitalInput;
import com.pi4j.io.gpio.PinState;

public class HCSR04 {

    private final GpioPinDigitalOutput trigger;
    private final GpioPinDigitalInput echo;
    private static final float soundSpeed = 340.3f * 100;

    public HCSR04(int triggerPinNumber, int echoPinNumber) {
        trigger = GpioControl.getInstance().getOutputPin(triggerPinNumber);
        trigger.setState(PinState.LOW);
        echo = GpioControl.getInstance().getInputPin(echoPinNumber);
        getDistance();
    }

    public float getDistance() {
        float result = 0.0F;
        trigger();
        if (!echoHigh()) {
            return -1;
        }
        long start = System.nanoTime();
        if (!echoLow()) {
            return -1;
        }
        long end = System.nanoTime();
        long pulse = end - start;
        result = pulse / 1_000_000_000F;
        result = result * soundSpeed / 2;
        return result;
    }

    private void trigger() {
        trigger.setState(true);
        UtilFunctions.delay(0, 10000);
        trigger.setState(false);
    }

    private boolean echoHigh() {
        long currentTimeMillis = System.currentTimeMillis();
        while (System.currentTimeMillis() - currentTimeMillis < 100) {
            if (echo.getState().isHigh()) {
                return true;
            }
        }
        return false;
    }

    private boolean echoLow() {
        long currentTimeMillis = System.currentTimeMillis();
        while (System.currentTimeMillis() - currentTimeMillis < 100) {
            if (echo.getState().isLow()) {
                return true;
            }
        }
        return false;
    }

   

}
