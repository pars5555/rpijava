/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hcsr04;

import com.pi4j.io.gpio.GpioController;
import com.pi4j.io.gpio.GpioFactory;
import com.pi4j.io.gpio.GpioPinDigitalInput;
import com.pi4j.io.gpio.GpioPinDigitalOutput;
import com.pi4j.io.gpio.RaspiPin;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author default
 */
public class GpioControl {

    private static GpioControl instance = null;
    private final GpioController gpio;
    private final Map<Integer, GpioPinDigitalOutput> outputPins;
    private final Map<Integer, GpioPinDigitalInput> inputPins;

    private GpioControl() {
        gpio = GpioFactory.getInstance();
        outputPins = new HashMap<>();
        inputPins = new HashMap<>();
    }

    public GpioPinDigitalOutput getOutputPin(Integer pinNumber) {
        if (outputPins.containsKey(pinNumber)) {
            return outputPins.get(pinNumber);
        }
        switch (pinNumber) {
            case 0:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_00));
                break;
            case 1:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_01));
                break;
            case 2:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_02));
                break;
            case 3:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_03));
                break;
            case 4:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_04));
                break;
            case 5:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_05));
                break;
            case 6:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_06));
                break;
            case 7:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_07));
                break;
            case 8:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_08));
                break;
            case 9:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_09));
                break;
            case 10:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_10));
                break;
            case 11:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_11));
                break;
            case 12:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_12));
                break;
            case 13:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_13));
                break;
            case 14:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_14));
                break;
            case 15:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_15));
                break;
            case 16:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_16));
                break;
            case 17:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_17));
                break;
            case 18:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_18));
                break;
            case 19:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_19));
                break;
            case 20:
                outputPins.put(pinNumber, gpio.provisionDigitalOutputPin(RaspiPin.GPIO_20));
                break;
        }
        return outputPins.get(pinNumber);
    }

    public GpioPinDigitalInput getInputPin(Integer pinNumber) {
        if (inputPins.containsKey(pinNumber)) {
            return inputPins.get(pinNumber);
        }
        switch (pinNumber) {
            case 0:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_00));
                break;
            case 1:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_01));
                break;
            case 2:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_02));
                break;
            case 3:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_03));
                break;
            case 4:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_04));
                break;
            case 5:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_05));
                break;
            case 6:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_06));
                break;
            case 7:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_07));
                break;
            case 8:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_08));
                break;
            case 9:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_09));
                break;
            case 10:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_10));
                break;
            case 11:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_11));
                break;
            case 12:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_12));
                break;
            case 13:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_13));
                break;
            case 14:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_14));
                break;
            case 15:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_15));
                break;
            case 16:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_16));
                break;
            case 17:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_17));
                break;
            case 18:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_18));
                break;
            case 19:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_19));
                break;
            case 20:
                inputPins.put(pinNumber, gpio.provisionDigitalInputPin(RaspiPin.GPIO_20));
                break;
        }
        return inputPins.get(pinNumber);
    }

    public static GpioControl getInstance() {
        if (instance == null) {
            instance = new GpioControl();
        }
        return instance;
    }

    public String setPinState(Integer pinNumber, boolean state) {
        if (state) {
            getOutputPin(pinNumber).high();
            return "Set GPIO pin #" + pinNumber.toString() + " state to HIGH";
        } else {
            getOutputPin(pinNumber).low();
            return "Set GPIO pin #" + pinNumber.toString() + " state to LOW";
        }
    }

    public String togglePinState(Integer pinNumber) {
        getOutputPin(pinNumber).toggle();
        return "Toggle GPIO pin #" + pinNumber.toString() + " state";
    }

    public String pulsePin(Integer pinNumber, Integer milliseconds) {
        getOutputPin(pinNumber).pulse(milliseconds);
        return "Pulse to GPIO pin #" + pinNumber.toString() + " duration: " + milliseconds.toString();
    }

}
