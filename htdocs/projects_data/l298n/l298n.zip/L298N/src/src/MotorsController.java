/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src;

import com.pi4j.io.gpio.GpioController;
import com.pi4j.io.gpio.GpioFactory;
import com.pi4j.io.gpio.GpioPinDigitalOutput;
import com.pi4j.io.gpio.Pin;
import com.pi4j.io.gpio.PinState;

/**
 *
 * @author default
 */
public class MotorsController {

    private static MotorsController instance = null;
    private final GpioController gpio;
    private GpioPinDigitalOutput leftMotorOutputPin1;
    private GpioPinDigitalOutput leftMotorOutputPin2;
    private GpioPinDigitalOutput rightMotorOutputPin1;
    private GpioPinDigitalOutput rightMotorOutputPin2;

    private MotorsController() {
        gpio = GpioFactory.getInstance();
    }

    public static MotorsController getInstance(Pin leftMotorPin1, Pin leftMotorPin2, Pin rightMotorPin1, Pin rightMotorPin2) {
        if (instance == null) {
            instance = new MotorsController();
        }
        instance.setConnectionPins(leftMotorPin1, leftMotorPin2, rightMotorPin1, rightMotorPin2);
        return instance;
    }
    
    public void setConnectionPins(Pin leftMotorPin1, Pin leftMotorPin2, Pin rightMotorPin1, Pin rightMotorPin2) {
        leftMotorOutputPin1 = gpio.provisionDigitalOutputPin(leftMotorPin1, PinState.LOW);
        leftMotorOutputPin2 = gpio.provisionDigitalOutputPin(leftMotorPin2, PinState.LOW);
        rightMotorOutputPin1 = gpio.provisionDigitalOutputPin(rightMotorPin1, PinState.LOW);
        rightMotorOutputPin2 = gpio.provisionDigitalOutputPin(rightMotorPin2, PinState.LOW);
    }

    public void goForward() {
        gpio.setState(PinState.HIGH, leftMotorOutputPin1);
        gpio.setState(PinState.LOW, leftMotorOutputPin2);
        gpio.setState(PinState.HIGH, rightMotorOutputPin1);
        gpio.setState(PinState.LOW, rightMotorOutputPin2);
    }

    public void stop() {
        gpio.setState(PinState.LOW, leftMotorOutputPin1);
        gpio.setState(PinState.LOW, leftMotorOutputPin2);
        gpio.setState(PinState.LOW, rightMotorOutputPin1);
        gpio.setState(PinState.LOW, rightMotorOutputPin2);
    }

    public void goBack() {
        gpio.setState(PinState.LOW, leftMotorOutputPin1);
        gpio.setState(PinState.HIGH, leftMotorOutputPin2);
        gpio.setState(PinState.LOW, rightMotorOutputPin1);
        gpio.setState(PinState.HIGH, rightMotorOutputPin2);
    }

}
